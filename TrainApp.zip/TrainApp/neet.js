class Solution {
  /**
   * @param {number[]} nums
   * @param {number} target
   * @return {number}
   */
  removeElement(nums, val) {
    let k = 0;
    for(let i = 0; i < nums.length; i++){
        if(nums[i]!== val){
            nums[k] = nums[i];
            k++;
        }
    }
    return k
  }
}

const check = new Solution();
console.log(check.removeElement([1,1,2,3,4], 1));
