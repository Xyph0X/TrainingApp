globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/fa2b5_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d9a00ddb._.js",
    "static/chunks/fa2b5_next_dist_compiled_react-dom_8cade648._.js",
    "static/chunks/fa2b5_next_dist_compiled_next-devtools_index_aef3194d.js",
    "static/chunks/fa2b5_next_dist_compiled_c549c92b._.js",
    "static/chunks/fa2b5_next_dist_client_440b3457._.js",
    "static/chunks/fa2b5_next_dist_d53f1dc1._.js",
    "static/chunks/fa2b5_@swc_helpers_cjs_7e98ec75._.js",
    "static/chunks/TrainApp_client_a0ff3932._.js",
    "static/chunks/turbopack-TrainApp_client_1cb8a296._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];