(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fa2b5_1ae741e5._.js",
  "static/chunks/TrainApp_client_src_app_registration_page_764b6d73.js"
],
    source: "dynamic"
});
