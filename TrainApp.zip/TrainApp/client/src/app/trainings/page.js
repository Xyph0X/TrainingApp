const trainings = () => {
  return <>You are on trainings page</>;
};

export default trainings;
