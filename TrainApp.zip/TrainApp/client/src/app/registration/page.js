"use client";
import axios from "axios";
import { useRouter } from "next/navigation";
import { useState } from "react";

const Registration = () => {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const registrationHandler = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.post(
        "http://localhost:5000/api/user/registration",
        {
          email,
          password,
        }
      );
      const { token } = result.data;
      if (token) {
        localStorage.setItem("token", token);
        console.log("Token saved:", token);
        router.push("/trainings");
      }
    } catch (e) {
      console.log(e.message);
    }
  };
  return (
    <div>
      <div>
        <input
          type="text"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
          }}
          placeholder="Type your email..."
          className="border m-2 "
          required
        />
      </div>
      <div>
        <input
          type="password"
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
          }}
          placeholder="Type your password..."
          className="border m-2"
          required
        />
      </div>
      <button className="border m-2" onClick={registrationHandler}>
        Submit
      </button>
    </div>
  );
};

export default Registration;
