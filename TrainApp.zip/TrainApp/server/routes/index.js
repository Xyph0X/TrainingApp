import express from "express";
import TrainingRouter from "./TrainingRouter.js";
import UserRouter from "./userRouter.js";
const router = express.Router();

router.use("/training", TrainingRouter);
router.use("/user", UserRouter);

export default router;
