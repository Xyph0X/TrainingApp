import { Router } from "express";
const TrainingRouter = new Router();
import TrainingController from "../controllers/TrainingController.js";

TrainingRouter.get("/", TrainingController.getAllTrainings);
TrainingRouter.post("/", TrainingController.putTraining);
TrainingRouter.patch("/:id", TrainingController.patchTraining);
TrainingRouter.delete("/:id", TrainingController.deleteTraining);

export default TrainingRouter;
