import ApiError from "../error/ApiError.js";
import { User, Trainings } from "../models/models.js";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import dotenv from "dotenv";
dotenv.config();

const generateJwt = (id, email) => {
  return jwt.sign({ id: User.id, email }, process.env.SECRET_KEY, {
    expiresIn: "24h",
  });
};

class userController {
  async registration(req, res, next) {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return next(ApiError.badRequest("Bad email or password"));
      }
      const candidate = await User.findOne({ where: { email } });
      if (candidate) {
        return next(ApiError.badRequest("User already exists"));
      }
      const hashedPassword = await bcrypt.hash(password, 6);
      const user = await User.create({ email, password: hashedPassword });
      const token = generateJwt(user.id, user.email);
      return res.json({ token });
    } catch (e) {
      console.log(e.message);
    }
  }
  async login(req, res, next) {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });
    if (!user) {
      return next(ApiError.internal("User not found"));
    }
    let comparePassword = bcrypt.compareSync(password, user.password);
    if (!comparePassword) {
      return next(ApiError.badRequest("Incorrect password"));
    }
    const token = generateJwt(user.id, user.email);
    res.json({token})
  }

  async check(req, res, next) {
    try {
      const user = req.user;

      const token = generateJwt(req.user.id, req.user.email);
      return res.json({ token, email: user.email });
    } catch (e) {
      console.log(e.message);
      res.status(500).json("Error in authorization");
    }
  }
}

export default new userController();
