import sequelize from "../db.js";
import { User, Trainings } from "./models.js";

User.hasMany(Trainings,{
  foreignKey:'userId',
  as: 'trainings'
});
Trainings.belongsTo(User,{
  foreignKey:'userId',
  as:'user'
});

export {sequelize,User, Trainings};