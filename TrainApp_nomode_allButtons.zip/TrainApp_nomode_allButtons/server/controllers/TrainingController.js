import ApiError from "../error/ApiError.js";
import { Trainings } from '../models/index.js';
class TrainingController {
  async getAllTrainings(req, res, next) {
    try {
      const userId = req.user.id;
      const result = await Trainings.findAndCountAll({where:{userId: userId}});
      res.json(result);
      console.log(result)
    } catch (e) {
      console.log(e.message);
      res.status(500).json({ message: "Server error" });
    }
  }
  async putTraining(req, res) {
    try {
      const { data, title, description} = req.body;
      const userId = req.user.id;
      const result = await Trainings.create({
        data,
        title,
        description,
        userId:userId
      });
      return res.json(result);
    } catch (e) {
      console.log(e.message);
      res.status(500).json({ message: "Server error" });
    }
  }
  async patchTraining(req, res) {
    try {

      const { data, title, description } = req.body;
      const userId = req.user.id;
      const result = await Trainings.findOne({ where: { userId:userId } });
      if (!result) {
        return next(ApiError.badRequest("No training found"));
      }
      if (!title || !description)
        return res.status(400).json({ message: "Missing fields" });
      if (data !== undefined) result.data = data;
      if (title !== undefined) result.title = title;
      if (description !== undefined) result.description = description;
      await result.save();
      return res.json(result);
    } catch (e) {
      console.log(e.message);
      res.status(500).json({ message: "Server error" });
    }
  }
  async deleteTraining(req, res) {
    try {
      const {id} =  req.params;
      const result = await Trainings.destroy({ where: { id:id } });
      if (!result)
        return res.status(400).json({ message: "No trainings found" });
      return res.status(200).json({ message: "Training deleted successfully" });
    } catch (e) {
      console.log(e.message);
      res.status(500).json("Server error");
    }
  }
}

export default new TrainingController();
