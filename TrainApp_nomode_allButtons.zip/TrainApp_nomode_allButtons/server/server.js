import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import router from "./routes/index.js";
import sequelize from "./db.js";
import ErrorHandlingMiddlewere from "./middlewere/ErrorHandlingMiddlewere.js";
dotenv.config();
const app = express();

const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(cors());
app.use(ErrorHandlingMiddlewere);
app.use("/api", router);

const start = async () => {
  try {
    await sequelize.authenticate();
    await sequelize.sync();
    app.listen(PORT, () => {
      console.log(`Server has started on port:${PORT}`);
    });
  } catch (e) {
    console.log(e.message);
  }
};

start();
