"use client";
import axios from "axios";
import { useState } from "react";
import { useRouter } from "next/navigation";
const Login = () => {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [messageError, setMessageError] = useState("");
  const loginHandler = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.post("http://localhost:5000/api/user/login", {
        email,
        password,
      });
      setMessageError("");

      const { token } = result.data;
      if (token) {
        localStorage.setItem("token", token);
        router.push("/trainings");
      }
    } catch (error) {
      setMessageError(
        error.response?.data?.message ||
          "User with this email and password doesnt exist"
      );
      console.log(e.message);
    }
  };
  return (
    <div>
      <div>
        <input
          type="text"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
          }}
          placeholder="Type your email..."
          className="border m-2 "
          required
        />
      </div>
      <div>
        <input
          type="password"
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
          }}
          placeholder="Type your password..."
          className="border m-2"
          required
        />
      </div>
      <button className="border m-2" onClick={loginHandler}>
        Submit
      </button>
      <p>
        No account yet? Try{" "}
        <button
          className="border w-13 ml-2 hover:cursor-pointer"
          onClick={() => {
            router.push("/registration");
          }}
        >
          Signup
        </button>
      </p>

      {messageError && (
        <div className="flex rounded-xl justify-center items-center fixed top-25 left-20 w-30 h-10 bg-red-500 font-semibold text-white ">
          {messageError}
        </div>
      )}
    </div>
  );
};
export default Login;
