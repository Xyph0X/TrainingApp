"use client";
import axios from "axios";
import { useEffect, useState } from "react";
import dayjs from "dayjs";

const TrainingComponent = () => {
  const [refresh, setRefresh] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [add, setAdd] = useState(false);
  const [selectedTraining, setSelectedTraining] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteMode, setDeleteMode] = useState(false);
  const saveAddHandler = async () => {
    const token = localStorage.getItem("token");
    const response = await axios.post(
      "http://localhost:5000/api/training",
      {
        data: dayjs().format("YYYY-MM-DD HH:mm:ss"),
        title: title,
        description: description,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    setRefresh(!refresh);
    setAdd(false);
  };
  const addHandler = () => {
    return (
      <div className="fixed top-25 left-55 bg-amber-200 w-53 h-50 ">
        {add && (
          <div>
            <h1 className="flex justify-center">Add training</h1>
            <input
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
              }}
              placeholder="Enter training name"
              className="border m-2"
            />
            <input
              value={description}
              onChange={(e) => {
                setDescription(e.target.value);
              }}
              placeholder="Enter training description"
              className="border m-2"
            />
            <button
              className="border p-2 m-2"
              onClick={() => {
                setAdd(false);
                setRefresh(!refresh);
              }}
            >
              CLOSE
            </button>
            <button
              className=" border ml-20 hover:cursor-pointer 
            "
              onClick={saveAddHandler}
            >
              Save
            </button>
          </div>
        )}
      </div>
    );
  };
  const saveEditHandler = async (training) => {
    if (!selectedTraining) return;
    const token = localStorage.getItem("token");
    await axios.patch(
      `http://localhost:5000/api/training/${selectedTraining.id}`,
      {
        data: dayjs().format("YYYY-MM-DD HH:mm:ss"),
        title: title,
        description: description,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    setIsEditing(false);
    setSelectedTraining(null);
    setEditMode(false);
    setRefresh(!refresh);
  };
  const editingHanlder = (training) => {
    setSelectedTraining(training);
    setTitle(training.title);
    setDescription(training.description);
    setIsEditing(true);
  };
  const deletingHandler = (training) => {
    setSelectedTraining(training);
    setIsDeleting(true);
  };
  const saveDeleteHandler = async (training) => {
    if (!selectedTraining) return;
    const token = localStorage.getItem("token");
    await axios.delete(
      `http://localhost:5000/api/training/${selectedTraining.id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    setDeleteMode(false);
    setIsDeleting(false);
    setRefresh(!refresh);
  };
  const [trainingData, setTrainingData] = useState(null);
  useEffect(() => {
    const fetchingTrainings = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) return console.log("No token found");
        const response = await axios.get("http://localhost:5000/api/training", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        setTrainingData(response.data.rows);
      } catch (e) {
        console.log(e.message);
      }
    };
    fetchingTrainings();
  }, [refresh]);

  return (
    <div>
      {trainingData ? (
        <div>
          <h2>
            My Trainings
            <button
              className="border p-2 m-2 hover:cursor-pointer"
              onClick={add === false ? () => setAdd(true) : () => setAdd(false)}
            >
              {" "}
              Add training{" "}
            </button>
            {add && addHandler()}
            <button
              className="border p-2 m-2 hover:cursor-pointer"
              onClick={
                editMode === false
                  ? () => setEditMode(true)
                  : () => setEditMode(false)
              }
            >
              {" "}
              Edit training{" "}
            </button>
            {isEditing && selectedTraining && (
              <div className="fixed top-25 left-55 bg-gray-500 w-53 h-50">
                <h1 className="flex justify-center">Edit training</h1>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter training name"
                  className="border m-2"
                />
                <input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Enter training description"
                  className="border m-2 "
                />
                <button
                  className="border p-2 m-2 hover:cursor-pointer"
                  onClick={() => {
                    setEditMode(false);
                    setIsEditing(false);
                    setRefresh(!refresh);
                  }}
                >
                  CLOSE
                </button>
                <button
                  onClick={saveEditHandler}
                  className="border p-2 ml-10 hover:cursor-pointer"
                >
                  Save
                </button>
              </div>
            )}
            <button
              className="border p-2 m-2 hover:cursor-pointer"
              onClick={
                deleteMode === false
                  ? () => setDeleteMode(true)
                  : () => setDeleteMode(false)
              }
            >
              Delete training
            </button>
            {isDeleting && selectedTraining && (
              <div className="fixed top-25 left-55 bg-gray-500 w-53 h-50">
                Are you sure that you want to delete this training?
                <button
                  className="border p-2 m-2 hover:cursor-pointer"
                  onClick={() => {
                    setDeleteMode(false);
                    setIsDeleting(false);
                    setRefresh(!refresh);
                  }}
                >
                  CLOSE
                </button>{" "}
                <button
                  className="border p-2 m-2 text-red hover:cursor-pointer"
                  onClick={saveDeleteHandler}
                >
                  DELETE
                </button>
              </div>
            )}
          </h2>
          {trainingData.length === 0 ? (
            <p>No trainings yet</p>
          ) : (
            <ul className="border w-50 justify-items-center p-2 ">
              {trainingData.map((training) => (
                <li
                  key={training.id}
                  training={training}
                  onClick={
                    editMode
                      ? () => editingHanlder(training)
                      : deleteMode
                      ? () => deletingHandler(training)
                      : null
                  }
                  className={
                    editMode
                      ? "border-2 border-green-500 p-2 m-2"
                      : deleteMode
                      ? "border-2 border-red-500 p-2 m-2"
                      : "border p-2 m-2"
                  }
                >
                  <h3>{training.data}</h3>
                  <h4>{training.title}</h4>
                  <p>{training.description}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default TrainingComponent;
