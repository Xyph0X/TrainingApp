globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/fa2b5_next_dist_compiled_next-devtools_index_132aec5a.js",
      "static/chunks/fa2b5_next_dist_compiled_0c8b2c3b._.js",
      "static/chunks/fa2b5_next_dist_shared_lib_cfb5543d._.js",
      "static/chunks/fa2b5_next_dist_client_a56de7e0._.js",
      "static/chunks/fa2b5_next_dist_51248d6d._.js",
      "static/chunks/fa2b5_next_app_277a0d7a.js",
      "static/chunks/[next]_entry_page-loader_ts_a2ccf2ca._.js",
      "static/chunks/fa2b5_react-dom_a93c20c3._.js",
      "static/chunks/fa2b5_16e56726._.js",
      "static/chunks/[root-of-the-server]__c9719fce._.js",
      "static/chunks/TrainApp_client_pages__app_2da965e7._.js",
      "static/chunks/turbopack-TrainApp_client_pages__app_5898a03a._.js"
    ],
    "/_error": [
      "static/chunks/fa2b5_next_dist_compiled_next-devtools_index_132aec5a.js",
      "static/chunks/fa2b5_next_dist_compiled_0c8b2c3b._.js",
      "static/chunks/fa2b5_next_dist_shared_lib_f92a7fb0._.js",
      "static/chunks/fa2b5_next_dist_client_a56de7e0._.js",
      "static/chunks/fa2b5_next_dist_04e9c16c._.js",
      "static/chunks/fa2b5_next_error_9436c69c.js",
      "static/chunks/[next]_entry_page-loader_ts_c4dde024._.js",
      "static/chunks/fa2b5_react-dom_a93c20c3._.js",
      "static/chunks/fa2b5_16e56726._.js",
      "static/chunks/[root-of-the-server]__44eb12a2._.js",
      "static/chunks/TrainApp_client_pages__error_2da965e7._.js",
      "static/chunks/turbopack-TrainApp_client_pages__error_f0cb3e9a._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/fa2b5_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d9a00ddb._.js",
    "static/chunks/fa2b5_next_dist_compiled_react-dom_8cade648._.js",
    "static/chunks/fa2b5_next_dist_compiled_next-devtools_index_aef3194d.js",
    "static/chunks/fa2b5_next_dist_compiled_c549c92b._.js",
    "static/chunks/fa2b5_next_dist_client_440b3457._.js",
    "static/chunks/fa2b5_next_dist_d53f1dc1._.js",
    "static/chunks/fa2b5_@swc_helpers_cjs_7e98ec75._.js",
    "static/chunks/TrainApp_client_a0ff3932._.js",
    "static/chunks/turbopack-TrainApp_client_1cb8a296._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];