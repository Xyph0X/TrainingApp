var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/fa2b5_dbec7779._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/TrainApp/client/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/TrainApp/client/node_modules/next/document.js [ssr] (ecmascript)").exports
