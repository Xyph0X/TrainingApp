var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/fa2b5_next_40d94019._.js")
R.c("server/chunks/[root-of-the-server]__af8073a3._.js")
R.m("[project]/TrainApp/client/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/TrainApp/client/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/TrainApp/client/src/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/TrainApp/client/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/TrainApp/client/src/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
