(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fa2b5_fcf5dbfa._.js",
  "static/chunks/TrainApp_client_components_TrainingComponent_167f2660.js"
],
    source: "dynamic"
});
