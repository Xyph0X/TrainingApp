__turbopack_load_page_chunks__("/_error", [
  "static/chunks/fa2b5_next_dist_compiled_next-devtools_index_132aec5a.js",
  "static/chunks/fa2b5_next_dist_compiled_0c8b2c3b._.js",
  "static/chunks/fa2b5_next_dist_shared_lib_f92a7fb0._.js",
  "static/chunks/fa2b5_next_dist_client_a56de7e0._.js",
  "static/chunks/fa2b5_next_dist_04e9c16c._.js",
  "static/chunks/fa2b5_next_error_9436c69c.js",
  "static/chunks/[next]_entry_page-loader_ts_c4dde024._.js",
  "static/chunks/fa2b5_react-dom_a93c20c3._.js",
  "static/chunks/fa2b5_16e56726._.js",
  "static/chunks/[root-of-the-server]__44eb12a2._.js",
  "static/chunks/TrainApp_client_pages__error_2da965e7._.js",
  "static/chunks/turbopack-TrainApp_client_pages__error_f0cb3e9a._.js"
])
