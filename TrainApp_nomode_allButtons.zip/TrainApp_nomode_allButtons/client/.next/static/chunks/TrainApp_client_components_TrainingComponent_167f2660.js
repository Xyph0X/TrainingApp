(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/TrainApp/client/components/TrainingComponent.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/TrainApp/client/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/TrainApp/client/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/TrainApp/client/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/TrainApp/client/node_modules/dayjs/dayjs.min.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const TrainingComponent = ()=>{
    _s();
    const [refresh, setRefresh] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [title, setTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [add, setAdd] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedTraining, setSelectedTraining] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editMode, setEditMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isEditing, setIsEditing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isDeleting, setIsDeleting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [deleteMode, setDeleteMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const saveAddHandler = async ()=>{
        const token = localStorage.getItem("token");
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("http://localhost:5000/api/training", {
            data: (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])().format("YYYY-MM-DD HH:mm:ss"),
            title: title,
            description: description
        }, {
            headers: {
                Authorization: "Bearer ".concat(token)
            }
        });
        setRefresh(!refresh);
        setAdd(false);
    };
    const addHandler = ()=>{
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed top-25 left-55 bg-amber-200 w-53 h-50 ",
            children: add && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "flex justify-center",
                        children: "Add training"
                    }, void 0, false, {
                        fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                        lineNumber: 40,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        value: title,
                        onChange: (e)=>{
                            setTitle(e.target.value);
                        },
                        placeholder: "Enter training name",
                        className: "border m-2"
                    }, void 0, false, {
                        fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                        lineNumber: 41,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        value: description,
                        onChange: (e)=>{
                            setDescription(e.target.value);
                        },
                        placeholder: "Enter training description",
                        className: "border m-2"
                    }, void 0, false, {
                        fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                        lineNumber: 49,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "border p-2 m-2",
                        onClick: ()=>{
                            setAdd(false);
                            setRefresh(!refresh);
                        },
                        children: "CLOSE"
                    }, void 0, false, {
                        fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                        lineNumber: 57,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: " border ml-20 hover:cursor-pointer    ",
                        onClick: saveAddHandler,
                        children: "Save"
                    }, void 0, false, {
                        fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                        lineNumber: 66,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                lineNumber: 39,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
            lineNumber: 37,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    };
    const saveEditHandler = async (training)=>{
        if (!selectedTraining) return;
        const token = localStorage.getItem("token");
        await __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].patch("http://localhost:5000/api/training/".concat(selectedTraining.id), {
            data: (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])().format("YYYY-MM-DD HH:mm:ss"),
            title: title,
            description: description
        }, {
            headers: {
                Authorization: "Bearer ".concat(token)
            }
        });
        setIsEditing(false);
        setSelectedTraining(null);
        setEditMode(false);
        setRefresh(!refresh);
    };
    const editingHanlder = (training)=>{
        setSelectedTraining(training);
        setTitle(training.title);
        setDescription(training.description);
        setIsEditing(true);
    };
    const deletingHandler = (training)=>{
        setSelectedTraining(training);
        setIsDeleting(true);
    };
    const saveDeleteHandler = async (training)=>{
        if (!selectedTraining) return;
        const token = localStorage.getItem("token");
        await __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete("http://localhost:5000/api/training/".concat(selectedTraining.id), {
            headers: {
                Authorization: "Bearer ".concat(token)
            }
        });
        setDeleteMode(false);
        setIsDeleting(false);
        setRefresh(!refresh);
    };
    const [trainingData, setTrainingData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TrainingComponent.useEffect": ()=>{
            const fetchingTrainings = {
                "TrainingComponent.useEffect.fetchingTrainings": async ()=>{
                    try {
                        const token = localStorage.getItem("token");
                        if (!token) return console.log("No token found");
                        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("http://localhost:5000/api/training", {
                            headers: {
                                Authorization: "Bearer ".concat(token)
                            }
                        });
                        setTrainingData(response.data.rows);
                    } catch (e) {
                        console.log(e.message);
                    }
                }
            }["TrainingComponent.useEffect.fetchingTrainings"];
            fetchingTrainings();
        }
    }["TrainingComponent.useEffect"], [
        refresh
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: trainingData ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    children: [
                        "My Trainings",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "border p-2 m-2 hover:cursor-pointer",
                            onClick: add === false ? ()=>setAdd(true) : ()=>setAdd(false),
                            children: [
                                " ",
                                "Add training",
                                " "
                            ]
                        }, void 0, true, {
                            fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                            lineNumber: 151,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        add && addHandler(),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "border p-2 m-2 hover:cursor-pointer",
                            onClick: editMode === false ? ()=>setEditMode(true) : ()=>setEditMode(false),
                            children: [
                                " ",
                                "Edit training",
                                " "
                            ]
                        }, void 0, true, {
                            fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                            lineNumber: 159,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        isEditing && selectedTraining && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "fixed top-25 left-55 bg-gray-500 w-53 h-50",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "flex justify-center",
                                    children: "Edit training"
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 172,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    value: title,
                                    onChange: (e)=>setTitle(e.target.value),
                                    placeholder: "Enter training name",
                                    className: "border m-2"
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 173,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    value: description,
                                    onChange: (e)=>setDescription(e.target.value),
                                    placeholder: "Enter training description",
                                    className: "border m-2 "
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 179,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "border p-2 m-2 hover:cursor-pointer",
                                    onClick: ()=>{
                                        setEditMode(false);
                                        setIsEditing(false);
                                        setRefresh(!refresh);
                                    },
                                    children: "CLOSE"
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 185,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: saveEditHandler,
                                    className: "border p-2 ml-10 hover:cursor-pointer",
                                    children: "Save"
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 195,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                            lineNumber: 171,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "border p-2 m-2 hover:cursor-pointer",
                            onClick: deleteMode === false ? ()=>setDeleteMode(true) : ()=>setDeleteMode(false),
                            children: "Delete training"
                        }, void 0, false, {
                            fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                            lineNumber: 203,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        isDeleting && selectedTraining && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "fixed top-25 left-55 bg-gray-500 w-53 h-50",
                            children: [
                                "Are you sure that you want to delete this training?",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "border p-2 m-2 hover:cursor-pointer",
                                    onClick: ()=>{
                                        setDeleteMode(false);
                                        setIsDeleting(false);
                                        setRefresh(!refresh);
                                    },
                                    children: "CLOSE"
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 216,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "border p-2 m-2 text-red hover:cursor-pointer",
                                    onClick: saveDeleteHandler,
                                    children: "DELETE"
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 226,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                            lineNumber: 214,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                    lineNumber: 149,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                trainingData.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "No trainings yet"
                }, void 0, false, {
                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                    lineNumber: 236,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                    className: "border w-50 justify-items-center p-2 ",
                    children: trainingData.map((training)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            training: training,
                            onClick: editMode ? ()=>editingHanlder(training) : deleteMode ? ()=>deletingHandler(training) : null,
                            className: editMode ? "border-2 border-green-500 p-2 m-2" : deleteMode ? "border-2 border-red-500 p-2 m-2" : "border p-2 m-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    children: training.data
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 258,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                    children: training.title
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 259,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: training.description
                                }, void 0, false, {
                                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                                    lineNumber: 260,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, training.id, true, {
                            fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                            lineNumber: 240,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)))
                }, void 0, false, {
                    fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
                    lineNumber: 238,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
            lineNumber: 148,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$TrainApp$2f$client$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: "Loading..."
        }, void 0, false, {
            fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
            lineNumber: 267,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/TrainApp/client/components/TrainingComponent.js",
        lineNumber: 146,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(TrainingComponent, "/rkQuTTZHA9RzqgAZMeXTl0wHow=");
_c = TrainingComponent;
const __TURBOPACK__default__export__ = TrainingComponent;
var _c;
__turbopack_context__.k.register(_c, "TrainingComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=TrainApp_client_components_TrainingComponent_167f2660.js.map