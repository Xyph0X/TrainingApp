(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a1e43b9e._.js",
  "static/chunks/src_app_login_page_4fed569d.js"
],
    source: "dynamic"
});
