(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fa2b5_next_5e0545d1._.js",
  "static/chunks/TrainApp_client_src_app_page_a5162fb3.js"
],
    source: "dynamic"
});
