(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d9a00ddb._.js",
  "static/chunks/fa2b5_next_dist_compiled_react-dom_8cade648._.js",
  "static/chunks/fa2b5_next_dist_compiled_next-devtools_index_aef3194d.js",
  "static/chunks/fa2b5_next_dist_compiled_c549c92b._.js",
  "static/chunks/fa2b5_next_dist_client_440b3457._.js",
  "static/chunks/fa2b5_next_dist_d53f1dc1._.js",
  "static/chunks/fa2b5_@swc_helpers_cjs_7e98ec75._.js"
],
    source: "entry"
});
