(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fa2b5_next_dist_compiled_next-devtools_index_132aec5a.js",
  "static/chunks/fa2b5_next_dist_compiled_0c8b2c3b._.js",
  "static/chunks/fa2b5_next_dist_shared_lib_cfb5543d._.js",
  "static/chunks/fa2b5_next_dist_client_a56de7e0._.js",
  "static/chunks/fa2b5_next_dist_51248d6d._.js",
  "static/chunks/fa2b5_next_app_277a0d7a.js",
  "static/chunks/[next]_entry_page-loader_ts_a2ccf2ca._.js",
  "static/chunks/fa2b5_react-dom_a93c20c3._.js",
  "static/chunks/fa2b5_16e56726._.js",
  "static/chunks/[root-of-the-server]__c9719fce._.js"
],
    source: "entry"
});
