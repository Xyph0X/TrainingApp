module.exports = [
"[project]/TrainApp/client/src/app/login/page.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/TrainApp/client/src/app/login/page.js'\n\nExpected 'from', got 'const'");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[project]/TrainApp/client/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/TrainApp/client/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
];

//# sourceMappingURL=TrainApp_client_374f3e32._.js.map