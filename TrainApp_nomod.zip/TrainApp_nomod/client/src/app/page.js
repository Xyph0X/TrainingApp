"use client";
import Image from "next/image";
import axios from "axios";
import { redirect } from "next/navigation";
export default function Home() {
  return (
    <div>
      <div>Welcome to the training tracker app</div>
      <div>
        Please
        <button
          className="m-4 border p-1 px-3 hover:cursor-pointer"
          onClick={() => redirect("./registration")}
        >
          Signup
        </button>
        or
        <button
          className="m-4 border p-1 px-3 hover:cursor-pointer"
          onClick={() => redirect("./login")}
        >
          Login
        </button>
        to start enjoying our app
      </div>
    </div>
  );
}
