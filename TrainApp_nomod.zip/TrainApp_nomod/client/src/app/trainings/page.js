import TrainingComponent from "../../../components/TrainingComponent";

// make welcome if comes from login, otherwise hello!
const Trainings = () => {
  return (
    <div>
      <p></p> 

      <p>Your last trainings:</p>
      <TrainingComponent/>
      

    </div>

  )
};

export default Trainings;
