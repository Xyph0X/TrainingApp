"use client";
import axios from "axios";
import { useEffect,useState } from "react";
import dayjs from "dayjs";

const TrainingComponent = ()=>{
  const [refresh, setRefresh] = useState(false);
  const [title, setTitle] = useState('');
  const [description,setDescription] = useState('');
  const [add,setAdd] = useState(false);
  const saveAddHandler = async()=>{
    const token = localStorage.getItem('token');
    const response = await axios.post("http://localhost:5000/api/training",{
          data: dayjs().format('YYYY-MM-DD HH:mm:ss'),
          title:title,
          description:description
        },{
          headers: {
    'Authorization': `Bearer ${token}`},
        },
    );

    setRefresh(!refresh);
    setAdd(false);
  }
  const addHandler =  ()=>{
  return(
    <div className  = "fixed top-25 left-55 bg-amber-200 w-53 h-50 ">{add && (<div >
            <h1 className = "flex justify-center">Add training</h1>
            <input 
            value={title}
            
            onChange={(e)=>{
              setTitle(e.target.value)
            }}
            placeholder="Enter training name"
            className = "border m-2" />
            <input
            value={description}
            
            onChange={(e)=>{
              setDescription(e.target.value)
            }} 
            placeholder="Enter training description" 
            className = "border m-2"/>
            <button className=" border ml-20 hover:cursor-pointer 
            "onClick={saveAddHandler}>Save</button>
          </div>)}</div>
  )    
  }
  const EditHandler =  ()=>{
  return(
    <div>wewe</div>
  )    
  }
  const DeleteHandler =  ()=>{
  return(
    <div>wewe</div>
  )    
  }
  const [trainingData,setTrainingData] = useState(null)
  useEffect(()=>{
    const fetchingTrainings = async ()=>{
      try{
        const token = localStorage.getItem('token');
        if (!token) return console.log("No token found")
        const response =  await axios.get("http://localhost:5000/api/training",{
          headers: {
    'Authorization': `Bearer ${token}`}
        });

        setTrainingData(response.data.rows)
      }catch(e){
        console.log(e.message);
        
      }
      
    } 
    fetchingTrainings();
  },[refresh])

  return (
    <div>{trainingData ? (
  <div>
    <h2>My Trainings 
      <button className="border p-2 m-2 hover:cursor-pointer " 
      onClick = {()=> setAdd(true)} > Add training </button  > 
      {add && addHandler()}
      <button className="border p-2 m-2" onClick = {EditHandler}> Edit training </button>
      <button className="border p-2 m-2" onClick = {DeleteHandler}> Delete training </button></h2>
    {trainingData.length === 0 ? (
      <p>No trainings yet</p>
    ) : (
      <ul className ='border w-50 justify-items-center p-2 '>
        {trainingData.map((training) => (
          <li key={training.id} className = 'border p-2 m-2'>
            <h3>{training.data}</h3>
            <h4>{training.title}</h4>
            <p>{training.description}</p>
          </li>
        ))}
      </ul>
    )}
  </div>
) : (
  <p>Loading...</p>
)}</div>

  )
}

export default TrainingComponent;