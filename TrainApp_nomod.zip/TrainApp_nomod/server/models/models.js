import sequelize from "../db.js";
import { DataTypes } from "sequelize";

export const User = sequelize.define("user", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  email: { type: DataTypes.STRING, unique: true },
  password: { type: DataTypes.STRING },
});

export const Trainings = sequelize.define("trainings", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  userId:{type:DataTypes.INTEGER, allowNull: false, references:{
    model:'users',
    key:'id'
  }},
  data: { type: DataTypes.STRING, allowNull: false },
  title: { type: DataTypes.STRING, allowNull: false },
  description: { type: DataTypes.STRING, allowNull: false },
});

