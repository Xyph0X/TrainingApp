import express from "express";
import TrainingRouter from "./TrainingRouter.js";
import UserRouter from "./userRouter.js";
import authMiddlewere from "../middlewere/authMiddlewere.js";
const router = express.Router();

router.use("/training",authMiddlewere, TrainingRouter);
router.use("/user", UserRouter);

export default router;
