import { Router } from "express";
import userController from "../controllers/userController.js";
import authMiddlewere from "../middlewere/authMiddlewere.js";
const UserRouter = new Router();

UserRouter.post("/registration", userController.registration);
UserRouter.post("/login", userController.login);
UserRouter.get("/auth", authMiddlewere, userController.check);

export default UserRouter;
